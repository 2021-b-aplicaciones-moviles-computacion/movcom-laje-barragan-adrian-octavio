package com.example.proyectofirebase

class BAuthUsuario {
    companion object {
        var usuario: FirestoreUsuarioDto?

        init {
            this.usuario = null;
        }
    }
}