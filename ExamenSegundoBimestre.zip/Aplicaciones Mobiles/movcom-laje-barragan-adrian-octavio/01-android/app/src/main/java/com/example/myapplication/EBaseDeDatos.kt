package com.example.myapplication

class EBaseDeDatos {
    companion object {
        var TablaUsuario: ESqliteHelperUsuario? = null
    }
}