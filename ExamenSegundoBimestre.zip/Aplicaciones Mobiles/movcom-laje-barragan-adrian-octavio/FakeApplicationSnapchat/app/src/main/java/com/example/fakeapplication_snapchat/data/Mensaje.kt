package com.example.fakeapplication_snapchat.data

class Mensaje(val mensaje: String,
val id:String,
val time: String) {
}